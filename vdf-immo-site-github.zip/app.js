async function filtrerBiens() {
  const ville = document.getElementById("ville").value.toLowerCase();
  const prix = parseInt(document.getElementById("prix").value);
  const type = document.getElementById("type").value;

  const response = await fetch("biens.json");
  const biens = await response.json();

  const annoncesEl = document.getElementById("annonces");
  annoncesEl.innerHTML = "";

  const filtres = biens.filter(b => {
    return (!ville || b.ville.toLowerCase().includes(ville)) &&
           (!prix || b.prix <= prix) &&
           (!type || b.type === type);
  });

  filtres.forEach(bien => {
    const div = document.createElement("div");
    div.className = "annonce";
    div.innerHTML = `
      <h3>${bien.titre}</h3>
      <p>${bien.ville} - ${bien.prix}€</p>
      <p>${bien.description}</p>
    `;
    annoncesEl.appendChild(div);
  });
}